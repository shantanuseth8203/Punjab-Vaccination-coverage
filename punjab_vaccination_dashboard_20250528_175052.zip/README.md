# Punjab Vaccination Coverage Dashboard 💉

A comprehensive Streamlit-based dashboard for analyzing and improving childhood vaccination coverage in rural Punjab. This dashboard provides interactive visualizations, real-time analytics, and actionable insights to help health officials make data-driven decisions.

## Features ✨

- **Interactive Geographic Maps** - Visual coverage mapping across Punjab districts
- **Real-time Analytics** - Comprehensive vaccination coverage statistics
- **Multi-theme Support** - Light and Dark theme options
- **Data Upload Support** - Upload your own vaccination datasets (CSV/Excel)
- **API Integration** - Connect to WHO, government health APIs
- **Export Capabilities** - Download reports and filtered data
- **Responsive Design** - Works on desktop and mobile devices

## Quick Start with Docker 🚀

### Prerequisites
- Docker installed on your system
- Docker Compose (included with Docker Desktop)

### Run with Docker Compose
```bash
# Clone or download the project
git clone <your-repo-url>
cd vaccination-dashboard

# Start the dashboard
docker-compose up -d

# View the dashboard
open http://localhost:5000
```

### Run with Docker only
```bash
# Build the image
docker build -t vaccination-dashboard .

# Run the container
docker run -p 5000:5000 vaccination-dashboard
```

## Local Development 🛠️

### Prerequisites
- Python 3.11+
- UV package manager

### Setup
```bash
# Install dependencies
uv sync

# Run the dashboard
uv run streamlit run app.py --server.port 5000
```

## Data Sources 📊

The dashboard supports multiple data sources:

### 1. File Upload
- Upload CSV or Excel files with vaccination data
- Required columns: `district`, `vaccine_type`, `coverage_percentage`
- Optional: `village`, `child_id`, `date`, `age_group`, `gender`

### 2. API Integration
- WHO Global Health Observatory
- India Government Open Data Platform
- Punjab State Health Department APIs

### 3. Database Connection
- PostgreSQL, MySQL, SQLite support
- Configure via environment variables

## Configuration ⚙️

### Environment Variables
```bash
# Data source configuration
VACCINATION_DATA_SOURCE=csv  # Options: csv, database, api
VACCINATION_DATA_PATH=vaccination_data.csv

# Database configuration (if using database)
DB_HOST=localhost
DB_NAME=vaccination_db
DB_USER=username
DB_PASSWORD=password

# API configuration (if using APIs)
VACCINATION_API_URL=your_api_endpoint
VACCINATION_API_KEY=your_api_key
```

### Docker Environment
```bash
# Copy and modify docker-compose.yml
# Add your environment variables under the 'environment' section
```

## Dashboard Sections 📈

### 1. Key Performance Indicators
- Total children tracked
- Average vaccination coverage
- Fully vaccinated percentage
- Districts covered

### 2. Geographic Overview
- Interactive map with coverage markers
- District-wise summary tables
- Color-coded coverage indicators

### 3. Coverage Analysis
- Vaccine-specific coverage charts
- Coverage distribution analysis
- Detailed vaccine comparisons

### 4. Trends & Timeline
- Time series analysis
- Monthly activity patterns
- Seasonal vaccination trends

### 5. Demographics
- Age group analysis
- Gender-based coverage
- Demographic breakdowns

### 6. Reports & Export
- Summary statistics
- Actionable recommendations
- Data export (CSV, reports)

## Themes 🎨

Switch between Light and Dark themes using the sidebar selector:
- **Light Theme**: Clean, professional appearance
- **Dark Theme**: Easy on the eyes for extended use

## Data Requirements 📋

### Minimum Required Columns
- `district`: Geographic district name
- `vaccine_type`: Type of vaccine (BCG, DPT, Polio, etc.)
- `coverage_percentage`: Coverage percentage (0-100)

### Additional Recommended Columns
- `village`: Village/locality name
- `child_id`: Unique child identifier
- `date`: Vaccination date
- `age_group`: Age category (0-12 months, 12-24 months)
- `gender`: Gender (Male/Female)

## Docker Details 🐳

### Multi-stage Build
- Uses Python 3.11 slim base image
- Installs UV package manager for fast dependency resolution
- Health checks included for monitoring

### Volumes
- `/app/data`: Mount point for external data files
- `/app/vaccination_data.csv`: Default data file location

### Ports
- Application runs on port 5000
- Mapped to host port 5000 by default

## Troubleshooting 🔧

### Common Issues

1. **Port already in use**
   ```bash
   # Change port in docker-compose.yml
   ports:
     - "8501:5000"  # Use port 8501 instead
   ```

2. **Data file not found**
   - Ensure your data file is in the correct location
   - Check file permissions
   - Verify file format (CSV/Excel)

3. **Theme not applying**
   - Clear browser cache
   - Refresh the page
   - Check browser developer tools for CSS errors

### Health Checks
The dashboard includes health monitoring:
```bash
# Check container health
docker ps

# View logs
docker-compose logs vaccination-dashboard
```

## Contributing 🤝

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with Docker
5. Submit a pull request

## License 📄

This project is licensed under the MIT License - see the LICENSE file for details.

## Support 💬

For questions or issues:
- Open an issue on GitHub
- Check the troubleshooting section
- Review the configuration options

---

**Built with ❤️ for improving healthcare outcomes in rural Punjab**