#!/bin/bash
# Punjab Vaccination Dashboard Startup Script
echo "🏥 Starting Punjab Vaccination Dashboard..."
echo ""

# Check if Docker is available
if command -v docker &> /dev/null && command -v docker-compose &> /dev/null; then
    echo "🐳 Docker detected - Starting with Docker (Recommended)"
    docker-compose up -d
    echo ""
    echo "✅ Dashboard starting at: http://localhost:5000"
    echo "⏳ Please wait 30-60 seconds for complete startup"
elif command -v python &> /dev/null; then
    echo "🐍 Python detected - Starting locally"
    # Install dependencies if needed
    if command -v uv &> /dev/null; then
        echo "Installing dependencies with UV..."
        uv sync
        uv run streamlit run app.py --server.port 5000
    else
        echo "Installing dependencies with pip..."
        pip install -r requirements.txt
        streamlit run app.py --server.port 5000
    fi
else
    echo "❌ Neither Docker nor Python found!"
    echo "Please install Docker Desktop or Python 3.11+ to continue"
    echo "See INSTALLATION_GUIDE.md for detailed instructions"
fi
